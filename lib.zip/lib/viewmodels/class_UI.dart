import 'package:flutter/material.dart';
import '../models/class.dart';
import '../services/database.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import '../services/firestore_service.dart';

class ClassViewModel extends ChangeNotifier {
  List<YogaClass> classes = [];

  Future<void> loadYogaClasses() async {
    classes = await DatabaseService.instance.readAllClasses();
    notifyListeners();
  }

  Future<void> addYogaClass(YogaClass yogaClass) async {
    await DatabaseService.instance.createClass(yogaClass);
    await loadYogaClasses();
    notifyListeners();
  }

  Future<void> updateYogaClass(YogaClass yogaClass) async {
    await DatabaseService.instance.updateClass(yogaClass);
    await loadYogaClasses();
  }

  Future<void> deleteYogaClass(int id) async {
    await DatabaseService.instance.deleteClass(id);
    await loadYogaClasses();
  }

  Future<void> uploadAllClassesToCloud(BuildContext context) async {
    final connectivity = await Connectivity().checkConnectivity();
    if (connectivity == ConnectivityResult.none) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('No internet connection')));
      return;
    }

    await FirestoreService.uploadAllClasses(classes);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Classes uploaded to cloud')));


  }

}