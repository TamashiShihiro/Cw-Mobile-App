import 'package:flutter/material.dart';
import '../models/class.dart';
import '../services/database.dart';

class ClassViewModel extends ChangeNotifier {
  List<YogaClass> classes = [];

  Future<void> loadYogaClasses() async {
    classes = await DatabaseService.instance.readAllClasses();
    notifyListeners();
  }

  Future<void> addYogaClass(YogaClass yogaClass) async {
    await DatabaseService.instance.createClass(yogaClass);
    await loadYogaClasses();
    notifyListeners();
  }

  Future<void> updateYogaClass(YogaClass yogaClass) async {
    await DatabaseService.instance.updateClass(yogaClass);
    await loadYogaClasses();
  }

  Future<void> deleteYogaClass(int id) async {
    await DatabaseService.instance.deleteClass(id);
    await loadYogaClasses();
  }

}