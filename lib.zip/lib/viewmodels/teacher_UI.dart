import 'package:flutter/material.dart';
import '../models/teacher.dart';
import '../services/database.dart';

class TeacherViewModel extends ChangeNotifier {
  List<Teacher> teachers = [];

  TeacherViewModel() {
    loadTeachers();
  }

  Future<void> loadTeachers() async {
    teachers = await DatabaseService.instance.readAllTeachers();
    notifyListeners();
  }

  Future<void> addTeacher(Teacher teacher) async {
    await DatabaseService.instance.createTeacher(teacher);
    await loadTeachers();
  }

  Future<void> updateTeacher(Teacher teacher) async {
    await DatabaseService.instance.updateTeacher(teacher);
    await loadTeachers();
  }

  Future<void> deleteTeacher(int id) async {
    await DatabaseService.instance.deleteTeacher(id);
    await loadTeachers();
  }
}
