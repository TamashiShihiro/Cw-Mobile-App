import 'package:flutter/material.dart';
import '../models/student.dart';
import '../services/database.dart';

class StudentViewModel extends ChangeNotifier {
  List<Student> students = [];

  StudentViewModel() {
    loadStudents();
  }

  Future<void> loadStudents() async {
    students = await DatabaseService.instance.readAllStudents();
    notifyListeners();
  }

  Future<void> addStudent(Student student ) async {
    await DatabaseService.instance.createStudent(student);
    await loadStudents();
  }

  Future<void> updateStudent(Student student ) async {
    await DatabaseService.instance.updateStudent(student);
    await loadStudents();
  }

  Future<void> deleteStudent(int id) async {
    await DatabaseService.instance.deleteStudent(id);
    await loadStudents();
  }
}
