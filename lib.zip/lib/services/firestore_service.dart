import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/class.dart';

class FirestoreService {
  static final _collection = FirebaseFirestore.instance.collection('classes');

  static Future<void> uploadClass(YogaClass yogaClass) async {
    await _collection.doc(yogaClass.id?.toString() ?? DateTime.now().millisecondsSinceEpoch.toString()).set(yogaClass.toMap());
  }

  static Future<void> uploadAllClasses(List<YogaClass> classes) async {
    final batch = FirebaseFirestore.instance.batch();
    for (final c in classes) {
      final doc = _collection.doc(c.id?.toString() ?? DateTime.now().millisecondsSinceEpoch.toString());
      batch.set(doc, c.toMap());
    }
    await batch.commit();
  }

}