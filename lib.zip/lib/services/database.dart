import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/class.dart';
import '../models/teacher.dart';
import '../models/student.dart';


class DatabaseService {
  static final DatabaseService instance = DatabaseService._init();

  static Database? _database;

  DatabaseService._init();



  Future<Database> get database async {
    if (_database != null) return _database!;

    _database = await _initDB('yoga_classes.db');
    return _database!;
  }


  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(path, version: 1, onCreate: _createDB);
  }


  Future _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE yoga_classes(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        day TEXT,
        date TEXT,
        time TEXT,
        type TEXT,
        capacity INTEGER,
        duration INTEGER,
        price REAL,
        teacherName TEXT,
        studentIds TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE teachers(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        phone INTEGER,
        email TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE students(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        phone INTEGER,
        email TEXT
        
      )
    ''');
  }




//CLASS CRUD
  Future<int> createClass(YogaClass yogaClass) async {
    final db = await instance.database;
    return await db.insert('yoga_classes', yogaClass.toMap());

  }

  Future<List<YogaClass>> readAllClasses() async {
    final db = await instance.database;
    final result = await db.query('yoga_classes');

    return result.map((map) => YogaClass.fromMap(map)).toList();

  }


  Future<int> updateClass(YogaClass yogaClass) async {
    final db = await instance.database;
    return db.update(
        'yoga_classes',
        yogaClass.toMap(),
        where: 'id = ?',
        whereArgs: [yogaClass.id]);
  }


  Future<int> deleteClass(int id) async {
    final db = await instance.database;
    return await db.delete('yoga_classes', where: 'id = ?', whereArgs: [id]);
  }


  Future close() async {
    final db = await instance.database;
    db.close();
  }


  //TEACHER CRUD
  Future<int> createTeacher(Teacher teacher) async {
    final db = await instance.database;
    return await db.insert('teachers', teacher.toMap());
  }

  Future<List<Teacher>> readAllTeachers() async {
    final db = await instance.database;
    final result = await db.query('teachers');

    return result.map((map) => Teacher.fromMap(map)).toList();
  }

  Future<int> updateTeacher(Teacher teacher) async {
    final db = await instance.database;
    return db.update(
        'teachers',
        teacher.toMap(),
        where: 'id = ?',
        whereArgs: [teacher.id]);

  }

  Future<int> deleteTeacher(int id) async {
    final db = await instance.database;
    return await db.delete('teachers', where: 'id = ?', whereArgs: [id]);
  }

  //Student CRUD

  Future<int> createStudent(Student student) async {
    final db = await instance.database;
    return await db.insert('students', student.toMap());
  }

  Future<List<Student>> readAllStudents() async {
    final db = await instance.database;
    final result = await db.query('students');
    return result.map((map) => Student.fromMap(map)).toList();
  }

  Future<int> updateStudent(Student student) async {
    final db = await instance.database;
    return db.update(
      'students',
      student.toMap(),
      where: 'id = ?',
      whereArgs: [student.id],
    );
  }

  Future<int> deleteStudent(int id) async {
    final db = await instance.database;
    return await db.delete('students', where: 'id = ?', whereArgs: [id]);
  }

  //reset all
  Future<void> resetAll() async {
    final db = await instance.database;
    await db.delete('yoga_classes');
    await db.delete('teachers');
    await db.delete('students');
  }


}

