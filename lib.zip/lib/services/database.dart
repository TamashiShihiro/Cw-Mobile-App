import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/class.dart';

class DatabaseService {
  static final DatabaseService instance = DatabaseService._init();

  static Database? _database;

  DatabaseService._init();



  Future<Database> get database async {
    if (_database != null) return _database!;

    _database = await _initDB('yoga_classes.db');
    return _database!;
  }


  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(path, version: 1, onCreate: _createDB);
  }


  Future _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE yoga_classes(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        day TEXT,
        time TEXT,
        capacity INTEGER,
        duration INTEGER,
        price REAL,
        type TEXT,
      )
    ''');

  }


  Future<int> createClass(YogaClass yogaClass) async {
    final db = await instance.database;
    return await db.insert('yoga_classes', yogaClass.toMap());

  }

  Future<List<YogaClass>> readAllClasses() async {
    final db = await instance.database;
    final result = await db.query('yoga_classes');

    return result.map((map) => YogaClass.fromMap(map)).toList();

  }


  Future<int> updateClass(YogaClass yogaClass) async {
    final db = await instance.database;
    return db.update(
        'yoga_classes',
        yogaClass.toMap(),
        where: 'id = ?',
        whereArgs: [yogaClass.id]);
  }


  Future<int> deleteClass(int id) async {
    final db = await instance.database;
    return await db.delete('yoga_classes', where: 'id = ?', whereArgs: [id]);
  }


  Future close() async {
    final db = await instance.database;
    db.close();
  }

}