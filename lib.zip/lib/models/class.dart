class YogaClass {
  final int? id;
  final String day;
  final String date;
  final String time;
  final String type;
  final int capacity;
  final int duration;
  final double price;
  final String? teacherName;
  final List<int>? studentIds;

  YogaClass({
    this.id,
    required this.day,
    required this.date,
    required this.time,
    required this.type,
    required this.capacity,
    required this.duration,
    required this.price,
    this.teacherName,
    this.studentIds,
  });


  factory YogaClass.fromMap(Map<String, dynamic> map) {
    return YogaClass(
      id: map['id'],
      day: map['day'],
      date: map['date'],
      time: map['time'],
      type: map['type'],
      capacity: map['capacity'],
      duration: map['duration'],
      price: map['price'] is int ? (map['price'] as int).toDouble() : map['price'],
      teacherName: map['teacherName'],
      studentIds: map['studentIds'] != null && map['studentIds'].toString().isNotEmpty
        ? map['studentIds'].toString().split(',').map((e) => int.parse(e)).toList()
        : [],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'day': day,
      'date': date,
      'time': time,
      'type': type,
      'capacity': capacity,
      'duration': duration,
      'price': price,
      'teacherName': teacherName,
      'studentIds': studentIds?.join(','),
    };
  }
}