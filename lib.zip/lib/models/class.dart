class YogaClass {
  final int? id;
  final String day;
  final String time;
  final int capacity;
  final int duration;
  final double price;
  final String type;

  YogaClass({
    this.id,
    required this.day,
    required this.time,
    required this.capacity,
    required this.duration,
    required this.price,
    required this.type,
  });


  factory YogaClass.fromMap(Map<String, dynamic> map) {
    return YogaClass(
      id: map['id'],
      day: map['day'],
      time: map['time'],
      capacity: map['capacity'],
      duration: map['duration'],
      price: map['price'] is int ? (map['price'] as int).toDouble() : map['price'],
      type: map['type'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'day': day,
      'time': time,
      'capacity': capacity,
      'duration': duration,
      'price': price,
      'type': type,
    };
  }
}