import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/teacher.dart';
import '../viewmodels/teacher_UI.dart';

class AddTeacherScreen extends StatefulWidget {
  final Teacher? teacherToEdit;
  const AddTeacherScreen({Key? key, this.teacherToEdit}) : super(key: key);

  @override
  State<AddTeacherScreen> createState() => _AddTeacherScreenState();

}

class _AddTeacherScreenState extends State<AddTeacherScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _emailController = TextEditingController();


  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _emailController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    if (widget.teacherToEdit != null) {
      final t = widget.teacherToEdit!;
      _nameController.text = t.name;
      _phoneController.text = t.phone.toString();
      _emailController.text = t.email;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text(
              widget.teacherToEdit != null ? 'Edit Teacher' : 'Add Teacher'),
          centerTitle: true,
        ),
        body: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Form(
                key: _formKey,
                child: SingleChildScrollView(

                    child: Column(
                        children: [
                          TextFormField(
                            controller: _nameController,
                            decoration: const InputDecoration(
                                labelText: 'Name'),
                            validator: (value) =>
                            value == null || value.isEmpty
                                ? 'Please enter a name'
                                : null,
                          ),

                          TextFormField(
                            controller: _phoneController,
                            decoration: const InputDecoration(
                                labelText: 'Phone'),
                            keyboardType: TextInputType.number,
                            validator: (value) =>
                            value == null || value.isEmpty
                                ? 'Please enter a phone number'
                                : null,
                          ),

                          TextFormField(
                            controller: _emailController,
                            decoration: const InputDecoration(labelText: 'Email'),
                            keyboardType: TextInputType.emailAddress,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please enter an email';
                              }
                              if (!value.contains('@')) {
                                return 'Invalid email';
                              }
                              return null;
                            },
                          ),
                          const SizedBox(height: 24),
                          ElevatedButton(
                              child: Text(widget.teacherToEdit == null
                                  ? 'Add Teacher'
                                  : 'Save Changes'),
                              onPressed: () async {
                                if (_formKey.currentState!.validate()) {
                                  final newTeacher = Teacher(
                                    id: widget.teacherToEdit?.id,
                                    name: _nameController.text,
                                    phone: int.parse(_phoneController.text),
                                    email: _emailController.text,
                                  );

                                  final provider = Provider.of<
                                      TeacherViewModel>(context, listen: false);

                                  if (widget.teacherToEdit == null) {
                                    await provider.addTeacher(newTeacher);
                                    if (mounted) {
                                      Navigator.pop(context);
                                      ScaffoldMessenger
                                          .of(context)
                                          .showSnackBar(
                                        const SnackBar(content: Text(
                                            'Teacher added successfully')),
                                      );
                                    }
                                  } else {
                                    await provider.updateTeacher(newTeacher);
                                    if (mounted) {
                                      Navigator.pop(context);
                                      ScaffoldMessenger
                                          .of(context)
                                          .showSnackBar(
                                        const SnackBar(content: Text(
                                            'Teacher updated successfully')),
                                      );
                                    }
                                  }
                                }
                              }
                          )
                        ]
                    )
                )
            )
        )
    );
  }
}