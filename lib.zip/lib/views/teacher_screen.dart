import 'package:provider/provider.dart';
import 'package:flutter/material.dart';
import '../viewmodels/teacher_UI.dart';
import 'add_teacher_screen.dart';

class TeacherScreen extends StatefulWidget {
  const TeacherScreen({super.key});
  @override
  State<TeacherScreen> createState() => _TeacherScreenState();

}

class _TeacherScreenState extends State<TeacherScreen> {
  int? selectedTeacherId;

  @override
  Widget build(BuildContext context) {
    final teacherVM = Provider.of<TeacherViewModel>(context);

    if (teacherVM.teachers.isEmpty) {
      teacherVM.loadTeachers();

    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Teachers'),
        centerTitle: true,
      ),
      body: teacherVM.teachers.isEmpty
          ? const Center(child: Text('No teachers found.'))
          : ListView.builder(
        itemCount: teacherVM.teachers.length,
        itemBuilder: (context, index) {
          final t = teacherVM.teachers[index];
          final isSelected = t.id == selectedTeacherId;
          return GestureDetector(
              onTap: () {
                setState(() {
                  selectedTeacherId = isSelected ? null : t.id;
                });
              },

              child: Container(
                decoration: BoxDecoration(
                  border: isSelected
                      ? Border.all(color: Colors.black, width: 2)
                      : Border.all(color: Colors.transparent),
                  borderRadius: BorderRadius.circular(8),
                ),
                margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                child: ListTile(
                  title: Text(t.name),
                  subtitle: Text('Phone: ${t.phone}, Email: ${t.email}'),
                ),
              )
          );
        },
      ),

      bottomNavigationBar: (selectedTeacherId != null)
          ? Padding(
        padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 12),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            ElevatedButton.icon(
              icon: const Icon(Icons.edit),
              label: const Text('Edit'),
              onPressed: () {
                final t = teacherVM.teachers.firstWhere((e) =>
                e.id == selectedTeacherId);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => AddTeacherScreen(teacherToEdit: t),
                  ),
                ).then((_) {
                  setState(() {
                    selectedTeacherId = null;
                  });
                });
              },
            ),
            ElevatedButton.icon(
              icon: const Icon(Icons.delete),
              label: const Text('Delete'),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
              onPressed: () async {
                await teacherVM.deleteTeacher(selectedTeacherId!);
                setState(() {
                  selectedTeacherId = null;
                });
              },
            ),
          ],
        ),
      )
          : null,

      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const AddTeacherScreen()),
          );
        },
      ),
    );
  }

}

