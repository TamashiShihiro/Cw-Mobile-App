import 'package:provider/provider.dart';
import 'package:flutter/material.dart';
import '../viewmodels/student_UI.dart';
import 'add_student_screen.dart';

class StudentScreen extends StatefulWidget {
  const StudentScreen({super.key});
  @override
  State<StudentScreen> createState() => _StudentScreenState();

}

class _StudentScreenState extends State<StudentScreen> {
  int? selectedStudentId;

  @override
  Widget build(BuildContext context) {
    final studentVM = Provider.of<StudentViewModel>(context);

    if (studentVM.students.isEmpty) {
      studentVM.loadStudents();

    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Students'),
        centerTitle: true,
      ),
      body: studentVM.students.isEmpty
          ? const Center(child: Text('No student found.'))
          : ListView.builder(
        itemCount: studentVM.students.length,
        itemBuilder: (context, index) {
          final t = studentVM.students[index];
          final isSelected = t.id == selectedStudentId;
          return GestureDetector(
              onTap: () {
                setState(() {
                  selectedStudentId = isSelected ? null : t.id;
                });
              },

              child: Container(
                decoration: BoxDecoration(
                  border: isSelected
                      ? Border.all(color: Colors.black, width: 2)
                      : Border.all(color: Colors.transparent),
                  borderRadius: BorderRadius.circular(8),
                ),
                margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                child: ListTile(
                  title: Text(t.name),
                  subtitle: Text('Phone: ${t.phone}, Email: ${t.email}'),
                ),
              )
          );
        },
      ),

      bottomNavigationBar: (selectedStudentId != null)
          ? Padding(
        padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 12),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            ElevatedButton.icon(
              icon: const Icon(Icons.edit),
              label: const Text('Edit'),
              onPressed: () {
                final t = studentVM.students.firstWhere((e) =>
                e.id == selectedStudentId);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => AddStudentScreen(studentToEdit: t),
                  ),
                ).then((_) {
                  setState(() {
                    selectedStudentId = null;
                  });
                });
              },
            ),
            ElevatedButton.icon(
              icon: const Icon(Icons.delete),
              label: const Text('Delete'),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
              onPressed: () async {
                await studentVM.deleteStudent(selectedStudentId!);
                setState(() {
                  selectedStudentId = null;
                });
              },
            ),
          ],
        ),
      )
          : null,

      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const AddStudentScreen()),
          );
        },
      ),
    );
  }

}

