import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../viewmodels/class_UI.dart';
import '../viewmodels/teacher_UI.dart';
import '../viewmodels/student_UI.dart';
import '../models/student.dart';
import '../models/class.dart';
import '../models/teacher.dart';

class AddClassScreen extends StatefulWidget {
  final YogaClass? yogaClassToEdit;
  const AddClassScreen({Key? key, this.yogaClassToEdit}) : super(key: key);

  @override
  State<AddClassScreen> createState() => _AddClassScreenState();
}


class _AddClassScreenState extends State<AddClassScreen> {
  final _formKey = GlobalKey<FormState>();
  final List<String> _times = ['09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00'];
  final List<String> _types = ['Flow Yoga', 'Aerial Yoga', 'Family Yoga'];

  final _durationController = TextEditingController();
  final _priceController = TextEditingController();
  final _dateController = TextEditingController();

  String? _selectedTeacherName;
  List<int> _selectedStudentIds = [];
  String? _selectedType;
  String? _day;
  String? _selectedTime;

  @override
  void dispose() {
    _dateController.dispose();
    _durationController.dispose();
    _priceController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    if (widget.yogaClassToEdit != null) {
      final c = widget.yogaClassToEdit!;
      _dateController.text = c.date;
      _durationController.text = c.duration.toString();
      _priceController.text = (c.price % 1 == 0) ? c.price.toInt().toString() : c.price.toString();
      _selectedTeacherName = c.teacherName;
      _selectedStudentIds = c.studentIds ?? [];
      _selectedType = c.type;
      _selectedTime = c.time;
      _dateController.text = c.date;
      _day = c.day;
    }
  }

  String? getWeekDay(String date) {
    try {
      final parts = date.split('/');
      if (parts.length != 3) return null;
      final dt = DateTime(int.parse(parts[2]), int.parse(parts[1]), int.parse(parts[0]));
      const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
      return days[dt.weekday - 1];
    } catch (e) {
      return null;

    }
  }



  @override
  Widget build(buildContext) {

    final teacherVM = Provider.of<TeacherViewModel>(context);
    final List<Teacher> teachers = teacherVM.teachers;

    final studentVM = Provider.of<StudentViewModel>(context);
    final List<Student> students = studentVM.students;

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.yogaClassToEdit != null ? 'Edit Yoga Class' : 'Add Yoga Class'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              children: [

                DropdownButtonFormField<String>(
                  decoration: const InputDecoration(labelText: 'Class Type'),
                  value: _selectedType,
                  items: _types.map((type) => DropdownMenuItem<String>(
                    value: type,
                    child: Text(type),
                  )).toList(),
                  onChanged: (String? value) {
                    setState(() {
                      _selectedType = value;
                    });
                  },
                  validator: (value) => value == null || value.isEmpty ? 'Please select a class type' : null,

                ),

                const SizedBox(height: 16),

                TextFormField(
                  controller: _dateController,
                  decoration: const InputDecoration(labelText: 'Date', hintText: 'DD/MM/YYYY'),
                  readOnly: true,
                  onTap: () async {
                    FocusScope.of(context).requestFocus(FocusNode());
                    DateTime? pickedDate = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime.now(),
                      lastDate: DateTime(2101),
                    );

                    if (pickedDate != null) {
                      String formattedDate = '${pickedDate.day.toString().padLeft(2, '0')}/${pickedDate.month.toString().padLeft(2, '0')}/${pickedDate.year}';
                      setState(() {
                        _dateController.text = formattedDate;
                        _day = getWeekDay(formattedDate);
                      });
                    }
                  },
                  validator: (value) => value == null || value.isEmpty ? 'Please enter a date' : null,
                ),

                const SizedBox(height: 16),
                if (_day != null)
                  Padding(padding: const EdgeInsets.only(top: 10, bottom: 16),
                  child: Row(
                    children: [
                      Text('Day: $_day', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500)),
                    ],
                  ),
                ),

                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  decoration: const InputDecoration(labelText: 'Time'),
                  value: _selectedTime,
                  items: _times.map((time) => DropdownMenuItem<String>(
                    value: time,
                    child: Text(time),
                  )).toList(),
                  onChanged: (String? value) {
                    setState(() {
                      _selectedTime = value;
                    });
                  },
                  validator: (value) => value == null || value.isEmpty ? 'Please select a time' : null,
                ),

                const SizedBox(height: 16),

                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Text(
                      'Number of students: ${_selectedStudentIds.length}',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                    ),
                  ],
                ),

                const SizedBox(height: 16),

                TextFormField(
                  controller: _durationController,
                  decoration: const InputDecoration(labelText: 'Duration'),
                  keyboardType: TextInputType.number,
                  validator: (value) {
                    if (value == null || value.isEmpty) { return 'Please enter a duration';
                    }

                    if (int.tryParse(value) == null) {
                      return 'Please enter a valid number for duration';
                    }
                    return null;
                  }
                ),

                TextFormField(
                  controller: _priceController,
                  decoration: const InputDecoration(labelText: 'Price'),
                  keyboardType: TextInputType.number,
                  validator: (value) {
                    if (value == null || value.isEmpty) { return 'Please enter a price';
                    }

                    if (int.tryParse(value) == null) {
                      return 'Please enter a valid number for price';
                    }
                    return null;
                  }
                ),

                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  decoration: const InputDecoration(labelText: 'Teacher Name'),
                  value: (teachers.any((t) => t.name == _selectedTeacherName)) ? _selectedTeacherName : null,
                  items: teachers.isNotEmpty
                    ? teachers.map((t) => DropdownMenuItem<String>(
                      value: t.name,
                      child: Text(t.name),
                    )).toList()
                    : [
                      const DropdownMenuItem<String>(
                        value: null,
                        child: Text('No teachers found'),
                      ),
                    ],
                  onChanged: teachers.isNotEmpty
                    ? (String? value) {
                      setState(() {
                        _selectedTeacherName = value;
                      });
                    }
                    : null,
                  validator: (value) {
                    if (teachers.isEmpty) {
                      return 'No teachers found';
                    }
                    if (value == null || value.isEmpty) {
                      return 'Please select a teacher';
                    }
                    return null;
                  }

                ),

                const SizedBox(height: 16),
                ExpansionTile(
                    title: Text('Select Student'),
                    children: students.isEmpty
                      ? [ListTile(title: Text('No students found'))]
                      : students.map((student) {
                        final isSelected = _selectedStudentIds.contains(student.id);
                        return CheckboxListTile(
                          title: Text(student.name),
                          value: isSelected,
                          onChanged: (selected) {
                            setState(() {
                              if (selected == true) {
                                _selectedStudentIds.add(student.id!);
                              } else {
                                _selectedStudentIds.remove(student.id);
                              }
                            });
                          },
                        );
                      }).toList()
                ),


                const SizedBox(height: 24),
                ElevatedButton(
                  child: Text(widget.yogaClassToEdit == null ? 'Add Yoga Class' : 'Save Changes'),
                  onPressed: () async {
                    if (_formKey.currentState!.validate()) {
                      final newClass = YogaClass(
                        id: widget.yogaClassToEdit?.id,
                        date: _dateController.text,
                        day: _day ?? '',
                        time: _selectedTime ?? '',
                        type: _selectedType ?? '',
                        capacity: _selectedStudentIds.length,
                        duration: int.parse(_durationController.text),
                        price: double.parse(_priceController.text),
                        teacherName: _selectedTeacherName,
                        studentIds: _selectedStudentIds,
                      );


                      final provider = Provider.of<ClassViewModel>(context, listen: false);

                      if (widget.yogaClassToEdit == null) {
                        await provider.addYogaClass(newClass);
                        if (mounted) {
                          Navigator.pop(context);
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Class added successfully')),
                          );
                        }
                      } else {
                        await provider.updateYogaClass(newClass);
                        if (mounted) {
                          Navigator.pop(context);
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Class updated successfully')),
                          );
                        }
                      }
                    }
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}