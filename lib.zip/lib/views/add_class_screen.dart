import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../viewmodels/class_UI.dart';
import '../models/class.dart';

class AddClassScreen extends StatefulWidget {
  final YogaClass? yogaClassToEdit;
  const AddClassScreen({Key? key, this.yogaClassToEdit}) : super(key: key);

  @override
  State<AddClassScreen> createState() => _AddClassScreenState();
}


class _AddClassScreenState extends State<AddClassScreen> {
  final _formKey = GlobalKey<FormState>();
  final _dayController = TextEditingController();
  final _timeController = TextEditingController();
  final _capacityController = TextEditingController();
  final _durationController = TextEditingController();
  final _priceController = TextEditingController();
  final _typeController = TextEditingController();

  @override
  void dispose() {
    _dayController.dispose();
    _timeController.dispose();
    _capacityController.dispose();
    _durationController.dispose();
    _priceController.dispose();
    _typeController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    if (widget.yogaClassToEdit != null) {
      final c = widget.yogaClassToEdit!;
      _dayController.text = c.day;
      _timeController.text = c.time;
      _capacityController.text = c.capacity.toString();
      _durationController.text = c.duration.toString();
      _priceController.text = c.price.toString();
      _typeController.text = c.type;
    }
  }



  @override
  Widget build(buildContext) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.yogaClassToEdit != null ? 'Edit Yoga Class' : 'Add Yoga Class'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(

            child: Column(
              children: [
                TextFormField(
                  controller: _dayController,
                  decoration: const InputDecoration(labelText: 'Day'),
                  validator: (value) => value == null || value.isEmpty ? 'Please enter a day' : null,
                ),

                TextFormField(
                  controller: _timeController,
                  decoration: const InputDecoration(labelText: 'Time'),
                  validator: (value) => value == null || value.isEmpty ? 'Please enter a time' : null,
                ),

                TextFormField(
                  controller: _capacityController,
                  decoration: const InputDecoration(labelText: 'Capacity'),
                  validator: (value) => value == null || value.isEmpty ? 'Please enter a capacity' : null,
                ),

                TextFormField(
                  controller: _durationController,
                  decoration: const InputDecoration(labelText: 'Duration'),
                  validator: (value) => value == null || value.isEmpty ? 'Please enter a duration' : null,
                ),

                TextFormField(
                  controller: _priceController,
                  decoration: const InputDecoration(labelText: 'Price'),
                  validator: (value) => value == null || value.isEmpty ? 'Please enter a price' : null,
                ),

                TextFormField(
                  controller: _typeController,
                  decoration: const InputDecoration(labelText: 'Type'),
                  validator: (value) => value == null || value.isEmpty ? 'Please enter a type' : null,
                ),
                const SizedBox(height: 24),
                ElevatedButton(
                  child: Text(widget.yogaClassToEdit != null ? 'Add Yoga Class' : 'Save Changes'),
                  onPressed: () async {
                    if (_formKey.currentState!.validate()) {
                      final newClass = YogaClass(
                        id: widget.yogaClassToEdit?.id,
                        day: _dayController.text,
                        time: _timeController.text,
                        capacity: int.parse(_capacityController.text),
                        duration: int.parse(_durationController.text),
                        price: double.parse(_priceController.text),
                        type: _typeController.text,
                      );


                      final provider = Provider.of<ClassViewModel>(context, listen: false);

                      if (widget.yogaClassToEdit == null) {
                        await provider.addYogaClass(newClass);
                        if (mounted) {
                          Navigator.pop(context);
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Class added successfully')),
                          );
                        }
                      } else {
                        await provider.updateYogaClass(newClass);
                        if (mounted) {
                          Navigator.pop(context);
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Class updated successfully')),
                          );
                        }
                      }
                    }
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}