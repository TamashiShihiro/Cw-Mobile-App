import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:yoga_app/views/student_screen.dart';
import 'package:yoga_app/views/teacher_screen.dart';
import '../viewmodels/class_UI.dart';
import '../viewmodels/teacher_UI.dart';
import '../viewmodels/student_UI.dart';
import 'add_class_screen.dart';
import '../services/database.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int? selectedClassId;


  @override
  Widget build(BuildContext context) {
    final classVM = Provider.of<ClassViewModel>(context);

    if (classVM.classes.isEmpty) {
      classVM.loadYogaClasses();
    }

    return Scaffold(
      drawer: Drawer(
        child: Stack(
          children: [
            ListView(
              padding: EdgeInsets.zero,
              children: [
                Container(
                  color: Colors.deepPurple,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      IconButton(
                        icon: Icon(Icons.close, color: Colors.white, size: 30),
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                      ),
                    ],
                  ),
                ),
                ListTile(
                  leading: Icon(Icons.person),
                  title: Text('Teachers'),
                  onTap: () {
                    Navigator.of(context).pop();
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const TeacherScreen()));
                    },
                ),
                ListTile(
                  leading: Icon(Icons.person),
                  title: Text('Students'),
                  onTap: () {
                    Navigator.of(context).pop();
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const StudentScreen()));
                  },
                ),
              ],
            ),
          ],
        ),
      ),




      appBar: AppBar(
        title: const Text('Yoga Classes'),
        centerTitle: true,


        actions: [

          IconButton(
            icon: Icon(Icons.cloud_upload),
            tooltip: 'Upload all classes to cloud',
            onPressed: () async {
              await Provider.of<ClassViewModel>(context, listen: false).uploadAllClassesToCloud(context);

              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Classes uploaded to cloud')),
                );
              }
            },
          ),

          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: () async {
              final confirmed = await showDialog(
                context: context,
                builder: (context) => AlertDialog(
                  title: Text('Reset All'),
                  content: Text('Are you sure you want to reset all data?'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context, false), child: Text('Cancel')),
                    ElevatedButton(onPressed: () => Navigator.pop(context, true), child: Text('Reset')),
                  ],
                ),
              );

              if (confirmed == true) {
                await DatabaseService.instance.resetAll();
                Provider.of<ClassViewModel>(context, listen: false).loadYogaClasses();
                Provider.of<TeacherViewModel>(context, listen: false).loadTeachers();
                Provider.of<StudentViewModel>(context, listen: false).loadStudents();
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('All data has been reset.')),
                  );
                }
              }

            },
          )
        ]
      ),
      body: classVM.classes.isEmpty
          ? const Center(child: Text('No yoga classes found.'))
          : ListView.builder(
        itemCount: classVM.classes.length,
        itemBuilder: (context, index) {
          final yc = classVM.classes[index];
          final isSelected = yc.id == selectedClassId;
          return GestureDetector(
            onTap: () {
              setState(() {

                selectedClassId = isSelected ? null : yc.id;
              });
            },
            child: Container(
              decoration: BoxDecoration(
                border: isSelected
                    ? Border.all(color: Colors.black, width: 2)
                    : Border.all(color: Colors.transparent),
                borderRadius: BorderRadius.circular(8),
              ),
              margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
              child: ListTile(
                title: Text('Type: ${yc.type} | Teacher: ${yc.teacherName} - ${yc.day} - Time: ${yc.time}'),
                subtitle: Text('Capacity: ${yc.capacity}, Duration: ${yc.duration} minutes, Price: £${yc.price}'),
              ),
            ),
          );
        },
      ),

      bottomNavigationBar: (selectedClassId != null)
          ? Padding(
        padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 12),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            ElevatedButton.icon(
              icon: const Icon(Icons.edit),
              label: const Text('Edit'),
              onPressed: () {
                final yc = classVM.classes.firstWhere((e) => e.id == selectedClassId);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => AddClassScreen(yogaClassToEdit: yc),
                  ),
                ).then((_) {
                  setState(() {
                    selectedClassId = null;
                  });
                });
              },
            ),
            ElevatedButton.icon(
              icon: const Icon(Icons.delete),
              label: const Text('Delete'),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
              onPressed: () async {
                await classVM.deleteYogaClass(selectedClassId!);
                setState(() {
                  selectedClassId = null;
                });
              },
            ),
          ],
        ),
      )
          : null,

      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const AddClassScreen()),
          );
        },
      ),
    );
  }
}
