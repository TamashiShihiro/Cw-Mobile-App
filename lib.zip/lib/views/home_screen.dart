import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../viewmodels/class_UI.dart';
import '../models/class.dart';
import 'add_class_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int? selectedClassId;

  @override
  Widget build(BuildContext context) {
    final yogaVM = Provider.of<ClassViewModel>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Yoga Classes'),
        centerTitle: true,
      ),
      body: yogaVM.classes.isEmpty
          ? const Center(child: Text('No yoga classes found.'))
          : ListView.builder(
        itemCount: yogaVM.classes.length,
        itemBuilder: (context, index) {
          final yc = yogaVM.classes[index];
          final isSelected = yc.id == selectedClassId;
          return GestureDetector(
            onTap: () {
              setState(() {

                selectedClassId = isSelected ? null : yc.id;
              });
            },
            child: Container(
              decoration: BoxDecoration(
                border: isSelected
                    ? Border.all(color: Colors.black, width: 2)
                    : Border.all(color: Colors.transparent),
                borderRadius: BorderRadius.circular(8),
              ),
              margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
              child: ListTile(
                title: Text('${yc.type} - ${yc.day} (${yc.time})'),
                subtitle: Text('Capacity: ${yc.capacity}, Price: ${yc.price}'),
              ),
            ),
          );
        },
      ),

      bottomNavigationBar: (selectedClassId != null)
          ? Padding(
        padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 12),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            ElevatedButton.icon(
              icon: const Icon(Icons.edit),
              label: const Text('Edit'),
              onPressed: () {
                final yc = yogaVM.classes.firstWhere((e) => e.id == selectedClassId);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => AddClassScreen(yogaClassToEdit: yc),
                  ),
                ).then((_) {
                  setState(() {
                    selectedClassId = null;
                  });
                });
              },
            ),
            ElevatedButton.icon(
              icon: const Icon(Icons.delete),
              label: const Text('Delete'),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
              onPressed: () async {
                await yogaVM.deleteYogaClass(selectedClassId!);
                setState(() {
                  selectedClassId = null;
                });
              },
            ),
          ],
        ),
      )
          : null,

      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const AddClassScreen()),
          );
        },
      ),
    );
  }
}
